function startGame(context) {
    addAction({
        type: "start_game",
    }, context);
}

function handleHelp(context) {
    addAction({
        type: "help",
    }, context);
}

function amountChoose(note, context) {
    addAction({
        type: "choose_amount",
        note: note
    }, context);
}

function mainMenu(context) {
    addAction({
        type: "main_menu",
    }, context);
}

function startQuiz(context) {
    addAction({
        type: "start_quiz",
    }, context);
}

function countryChooseByName(country_name, context){
    addAction({
        type: "country_choose_by_name",
        country_name: country_name
    }, context);
}


